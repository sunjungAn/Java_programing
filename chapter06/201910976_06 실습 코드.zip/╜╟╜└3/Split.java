import java.io.*;

public class Split {
	public static void main(String[] args) throws IOException
	{
		InputStreamReader rd = new InputStreamReader(System.in);
		System.out.println("");
		int cnt = 1;
		while(true) {
			
			int n = rd.read();
			if(n == -1)break;
			if(n ==' ') cnt++;
		}
		System.out.println("�ܾ��� ����: "+cnt);
	}
}
