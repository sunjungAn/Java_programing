import java.util.*;

public class query {
	public static void main(String []args)
	{
		String str=args[0];
		StringTokenizer st = new StringTokenizer(str, "&=");
		while(st.hasMoreTokens())
			System.out.println(st.nextToken()+'\t'+st.nextToken());
		
	}
}
