import java.util.Scanner;
import java.util.Random;

class Person{
	String name;
	int tmp [] = new int[3];
	Person(String name)
	{
		this.name = name;
	}
	
}
public class Gamble {
	
	public static boolean checkRandNum() {
		int[] tmp = new int[3];
		
		for(int i = 0; i<3; i++)
		{
			double d = Math.random()*3;
			int n = (int)(Math.round(d));
			tmp[i] = n;
			System.out.print(n+" ");
		}
		System.out.println();
		if (tmp[0] == tmp[1] && tmp[0] == tmp[2] && tmp[1] == tmp[2]) 
			return true; 
		else return false; 
	}
	
	public static void main(String [] args)
	{
		Person p[] = new Person[2];
		Scanner sc = new Scanner(System.in);
		System.out.print("user 1 :");
		String user = sc.nextLine();
		p[0] = new Person(user);
		System.out.print("user 2 :");
		user = sc.nextLine(); 
		p[1] = new Person(user);
		int count = 0;
		String c;
		while(true) {
			System.out.println(p[count%2].name+"���� ");
			c = sc.nextLine();
			if(c.equals(""))
			{
				 if(checkRandNum())
				{
					System.out.println(p[count%2].name+"�� �̰���ϴ�.");
					return;
				}
				count++;	
			}
		}
	}
}
