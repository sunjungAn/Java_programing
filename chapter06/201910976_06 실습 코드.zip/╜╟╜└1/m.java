package main;

import lib.a;

public class m {
	public static void main(String [] args)
	{
		a c = new a();
		System.out.println(c.sum(2, 3));
	}
}
